**To delete a resource share**

The following ``delete-resource-share`` example deletes the specified resource share. ::

    aws ram delete-resource-share \
        --resource-share-arn arn:aws:ram:us-west-2:123456789012:resource-share/7ab63972-b505-7e2a-420d-6f5d3EXAMPLE

The following output indicates success::

    {
        "returnValue": true
    }
